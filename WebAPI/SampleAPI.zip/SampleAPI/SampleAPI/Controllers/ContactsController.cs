﻿using SampleAPI.Models;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Web.Http;

namespace SampleAPI.Controllers
{
    public class ContactsController : ApiController
    {

        public IHttpActionResult Get()
        {
            ICollection<Contact> Contacts = new Collection<Contact>();

            for(int i = 1; i <= 20;i++)
            {
                Contact newContact = new Contact();
                newContact.Id = i;
                newContact.FirstName = "First" + i.ToString();
                newContact.MiddleName = "Middle" + i.ToString();
                newContact.LastName = "Last" + i.ToString();
                newContact.Email = newContact.FirstName + "@Domain" + i.ToString() + ".com";
                Contacts.Add(newContact);
            }

            return Ok(Contacts);
        }


        public IHttpActionResult Post(int Id)
        {
            Contact newContact = new Contact();
                newContact.Id = Id;
                newContact.FirstName = "First" + Id.ToString();
                newContact.MiddleName = "Middle" + Id.ToString();
                newContact.LastName = "Last" + Id.ToString();
                newContact.Email = newContact.FirstName + "@Domain" + Id.ToString() + ".com";

            return Ok(newContact);
        }
    }
}
